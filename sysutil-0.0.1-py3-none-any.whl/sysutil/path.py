import json
class Reuse:
    def get_path(temp,path,list):
            list.append(temp)
            with open(path,"w") as file:
                file.writelines(json.dumps(list))      
           
            

            
    